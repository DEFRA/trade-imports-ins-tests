import { test, expect } from '@fixtures';
import { notificationFulfilmentsStatuses } from '@domain/animals/models/api/notification-fulfilments';
import { notificationStatuses } from '@domain/animals/models/api/notification';

test.describe('Notification lifecycle', { tag: '@compose' }, () => {
  test('creates, submits, amends, cancels, copies and soft-deletes a notification; fulfilment view reflects each transition; each copy gets its own reference number', async ({
    notificationApi,
    journeyContext,
  }) => {
    const notification = await notificationApi.createNotification({ fulfilments: [] });
    const id = notification.referenceNumber;
    journeyContext.recordReferenceNumber(id);
    expect(notification.status).toBe(notificationStatuses.draft);

    const initial = await notificationApi.getNotificationFulfilments(id);
    expect(initial.referenceNumber).toBe(id);
    expect(initial.status).toBe(notificationFulfilmentsStatuses.draft);
    expect(initial.fulfilments).toEqual([]);

    const submitted = await notificationApi.submitNotification(id, notification.concurrencyToken);
    expect(submitted.status).toBe(notificationStatuses.submitted);
    const submittedFulfilments = await notificationApi.getNotificationFulfilments(id);
    expect(submittedFulfilments.status).toBe(notificationFulfilmentsStatuses.submitted);

    const amended = await notificationApi.amendNotification(id);
    expect(amended.status).toBe(notificationStatuses.amend);
    const amendedFulfilments = await notificationApi.getNotificationFulfilments(id);
    expect(amendedFulfilments.status).toBe(notificationFulfilmentsStatuses.amend);

    const cancelled = await notificationApi.cancelAmendNotification(id);
    expect(cancelled.status).toBe(notificationStatuses.submitted);

    const firstCopy = await notificationApi.copyNotification(id, cancelled.concurrencyToken);
    journeyContext.recordReferenceNumber(firstCopy.referenceNumber);
    const secondCopy = await notificationApi.copyNotification(id, cancelled.concurrencyToken);
    journeyContext.recordReferenceNumber(secondCopy.referenceNumber);
    expect(firstCopy.referenceNumber).not.toBe(id);
    expect(secondCopy.referenceNumber).not.toBe(firstCopy.referenceNumber);
    expect(firstCopy.status).toBe(notificationStatuses.draft);
    expect(secondCopy.status).toBe(notificationStatuses.draft);

    const deleted = await notificationApi.softDeleteNotification(id);
    expect(deleted.status).toBe(notificationStatuses.deleted);
    const repeatDelete = await notificationApi.softDeleteNotification(id);
    expect(repeatDelete.status).toBe(notificationStatuses.deleted);
  });

  test('renders a submitted notification read-only and opens an amendment at the review page', async ({
    animalsJourney,
    journeyContext,
    pages,
    animalsPages,
    animalsNotificationActions,
  }) => {
    test.slow();
    await animalsJourney.submitNotification();
    await animalsNotificationActions.toNotificationView(journeyContext.referenceNumber);

    await expect(animalsPages.notificationView.heading).toBeVisible();
    await expect(animalsPages.notificationView.journeyStrip).toContainText('Submitted');
    await expect(pages.page.getByRole('link', { name: /^Change/ })).toHaveCount(0);
    await animalsNotificationActions.amendNotification(journeyContext.referenceNumber);
    await expect(animalsPages.notificationView.heading).toBeVisible();
    await expect(animalsPages.notificationView.statusTag).toHaveText('Amend');
  });

  test("Back from a submitted notification's view opens the notification list", async ({
    animalsJourney,
    journeyContext,
    animalsPages,
  }) => {
    test.slow();
    await animalsJourney.submitNotification();

    await animalsPages.dashboard.open();
    await animalsPages.dashboard.searchForReference(journeyContext.referenceNumber);
    await animalsPages.dashboard.view(journeyContext.referenceNumber).click();
    await expect(animalsPages.notificationView.heading).toBeVisible();
    await animalsPages.notificationView.linkBack.click();
    await expect(animalsPages.dashboard.heading).toBeVisible();
  });

  test('Back from an amendment review opened by Amend on the dashboard opens the dashboard', async ({
    animalsJourney,
    journeyContext,
    animalsPages,
    animalsNotificationActions,
  }) => {
    test.slow();
    await animalsJourney.submitNotification();

    await animalsNotificationActions.amendNotification(journeyContext.referenceNumber);
    await expect(animalsPages.notificationView.heading).toBeVisible();
    await animalsPages.notificationView.linkBack.click();
    await expect(animalsPages.dashboard.heading).toBeVisible();
  });
});
