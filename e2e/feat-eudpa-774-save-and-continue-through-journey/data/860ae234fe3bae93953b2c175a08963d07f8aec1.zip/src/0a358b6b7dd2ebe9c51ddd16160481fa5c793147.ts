import { SET_BASES } from '@page-objects/shared/sets';

import { test, expect } from '@fixtures';

test(
  'submits a promoted live-animals notification through the hub-owned spine',
  { tag: '@compose' },
  async ({ animalsJourney, pages, journeyContext }) => {
    test.slow();
    await animalsJourney.submitNotification();

    await expect(pages.page.getByRole('heading', { name: 'Import notification submitted' })).toBeVisible();
    await expect(pages.page).toHaveURL(
      new RegExp(`${SET_BASES.liveAnimals}/notifications/${journeyContext.referenceNumber}/confirmation$`),
    );
    await expect(pages.page.locator('.govuk-panel')).toContainText(journeyContext.referenceNumber);
  },
);
